package com.girslAIPK.eldetech;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class OptionPage extends AppCompatActivity implements View.OnClickListener {
    Button signin, login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.option_page);
        signin = findViewById(R.id.signupbtn);
        login = findViewById(R.id.loginbtn);

        signin.setOnClickListener((View.OnClickListener) this);
        login.setOnClickListener((View.OnClickListener) this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.signupbtn:
                Intent intent1 = new Intent(OptionPage.this, Signup.class);
                startActivity(intent1);
                break;
            case R.id.loginbtn:
                Intent intent2 = new Intent(OptionPage.this, Login.class);
                startActivity(intent2);
                break;
        }
    }

}