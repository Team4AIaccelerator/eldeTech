package com.girslAIPK.eldetech;

import androidx.appcompat.app.AppCompatActivity;

public class VideoPage extends AppCompatActivity {
}
