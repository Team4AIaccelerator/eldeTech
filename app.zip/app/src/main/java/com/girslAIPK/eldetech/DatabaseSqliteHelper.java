package com.girslAIPK.eldetech;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.girslAIPK.eldetech.User;


public class DatabaseSqliteHelper extends SQLiteOpenHelper{
        //Table Name
        public static final String TABLE_NAME = "user";
        // Database Version
        private static final int DATABASE_VERSION = 1;

        // Database Name
        private static final String DATABASE_NAME = "UserManager.db";

        // User Table Columns names
        public static final String COLUMN_USER_ID = "user_id";
        public static final String COLUMN_USER_NAME = "user_name";
        public static final String COLUMN_USER_PROFESSION = "user_profession";
        public static final String COLUMN_USER_AGE = "user_age";
        public static final String COLUMN_USER_EMAIL = "user_email";
        public static final String COLUMN_USER_PASSWORD = "user_password";

        // create table sql query
        private String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_NAME + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USER_NAME + " TEXT,"
                + COLUMN_USER_PROFESSION + " TEXT,"
                + COLUMN_USER_AGE + " TEXT,"
                + COLUMN_USER_EMAIL + " TEXT,"
                + COLUMN_USER_PASSWORD + " TEXT" + ")";

        // drop table sql query
        private String DROP_USER_TABLE = "DROP TABLE IF EXISTS " + TABLE_NAME;

        /**
         * Constructor
         *
         * @param context
         */
        public DatabaseSqliteHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(CREATE_USER_TABLE);
        }


        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

            //Drop User Table if exist
            db.execSQL(DROP_USER_TABLE);

            // Create tables again
            onCreate(db);

        }

        //Add user in Database
        public void addUser(User user) {
            SQLiteDatabase db = this.getWritableDatabase();

            ContentValues values = new ContentValues();

            values.put(COLUMN_USER_NAME, user.name);
            values.put(COLUMN_USER_EMAIL, user.email);
            values.put(COLUMN_USER_PASSWORD, user.password);

            //Inserting row
            db.insert(TABLE_NAME, null, values);

            //Close the database
            db.close();
        }

        public User Authenticate(User user) {

            // array of columns to fetch
            String[] columns = {
                    COLUMN_USER_ID,
                    COLUMN_USER_NAME,
                    COLUMN_USER_EMAIL,
                    COLUMN_USER_PASSWORD
            };
            SQLiteDatabase db = this.getReadableDatabase();

            Cursor cursor = db.query(TABLE_NAME, //Table to query
                    columns,                    //columns to return
                    null,                  //columns for the WHERE clause
                    null,              //The values for the WHERE clause
                    null,                       //group the rows
                    null,                       //filter by row groups
                    null);                      //The sort order
            if (cursor != null && cursor.moveToFirst() && cursor.getCount() > 0) {
                do {

                    User user1 = new User(cursor.getString(cursor.getColumnIndex(this.COLUMN_USER_ID)),
                            cursor.getString(cursor.getColumnIndex(this.COLUMN_USER_NAME)),
                            cursor.getString(cursor.getColumnIndex(this.COLUMN_USER_PROFESSION)),
                            cursor.getString(cursor.getColumnIndex(this.COLUMN_USER_AGE)),
                            cursor.getString(cursor.getColumnIndex(this.COLUMN_USER_EMAIL)),
                            cursor.getString(cursor.getColumnIndex(this.COLUMN_USER_PASSWORD)));

                    if (user.password.equalsIgnoreCase(user1.password) && user.email.equals(user1.email)) {
                        return user1;

                    }
                } while (cursor.moveToNext());

            }
            cursor.close();
            return null;
        }

        public boolean isEmailExists(String email) {
            SQLiteDatabase db = this.getReadableDatabase();

            // array of columns to fetch
            String[] columns = {COLUMN_USER_EMAIL};

            //Selection
            String selection = COLUMN_USER_EMAIL + " = ? ";

            //Selection Args
            String[] selection_Args = {email};

            //Query
            Cursor cursor = db.query(TABLE_NAME,
                    columns,
                    selection,
                    selection_Args,
                    null,
                    null,
                    null
            );

            if (cursor != null && cursor.moveToFirst() && cursor.getCount() > 0) {
                return true;
            }
            return false;
        }
}

