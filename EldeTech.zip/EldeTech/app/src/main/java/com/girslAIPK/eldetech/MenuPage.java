package com.girslAIPK.eldetech;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MenuPage extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.menu_page);

        }

}
