package com.girslAIPK.eldetech;

public class User {

        //Variable
        public String id;
        public String name;
        public String profession;
        public String age;
        public String email;
        public String password;

        //Constructor with two parameters
        public User(String email, String password) {
            this.email = email;
            this.password = password;
        }

        //Parameter Constructor containing all three parameter
        public User(String id, String name, String profession, String age, String email, String password) {
            this.id = id;
            this.name = name;
            this.profession = profession;
            this.age = age;
            this.email = email;
            this.password = password;

        }

}
